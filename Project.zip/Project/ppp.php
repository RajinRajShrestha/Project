<html>
 <head>
  <title>
   UEFA Champions League Standings
  </title>
  <style>
   body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .header {
            position: sticky;
            top: 0px;
            background-color: #0b2545;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
        }
        .header h1 {
            font-size: 18px;
            margin: 0;
        }
        .nav {
            position: sticky;
            top: 41px;
            background-color: #0b2545;
            color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
        }
        .nav a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
        }
        .nav a.active {
            border-bottom: 2px solid white;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        a{
            color: black;
            text-decoration: none;
        }
        .matchday {
            padding: 10px 20px;
            border-bottom: 1px solid #ddd;
            font-size: 18px;
            font-weight: bold;
        }
        .match {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            border-bottom: 1px solid #ddd;
        }
        .team {
            display: flex;
            align-items: center;
            flex: 1;
        }
        .team img {
            width: 24px;
            height: 24px;
            margin-right: 10px;
        }
        .team span {
            margin-left: 10px;
        }
        .score {
            font-size: 18px;
            font-weight: bold;
            margin: 0 20px;
        }
        .status {
            font-size: 14px;
            color: #888;
            text-align: center;
            width: 60px;
        }
  </style>
 </head>
 <body>
    <?php
    echo "
  <div class="header">
   <h1>
    UEFA Champions League
   </h1>
  </div>
  <div class="nav">
   <a class="active" href="Match.html">
    MATCHES
   </a>
   <a href="News.html">
    NEWS
   </a>
   <a href="Standings 2024-25.html">
    STANDINGS
   </a>
   <a href="Top scorer.html">
    STATS
   </a>
   <a href="Players.html">
    PLAYERS
   </a>
  </div>
  <div class="container">
    <div class="matchday">
     Matchday 1 of 8
    <div class="match">
     <div class="team">
      <img alt="Juventus logo" height="24" src="Juventus.png" width="24"/>
      <span>
       Juventus
      </span>
     </div>
     <div class="score">
      3
     </div>
     <div class="status">
      FT
      <br/>
      Sep 17
     </div>
     <div class="score">
      1
     </div>
     <div class="team" style="justify-content: flex-end;">
      <span>
       PSV
      </span>
      <img alt="PSV logo" height="24" src="PSV.png" width="24"/>
     </div>
    </div>
    <div class="match">
     <div class="team">
      <img alt="Young Boys logo" height="24" src="Young Boys.png" width="24"/>
      <span>
       Young Boys
      </span>
     </div>
     <div class="score">
      0
     </div>
     <div class="status">
      FT
      <br/>
      Sep 17
     </div>
     <div class="score">
      3
     </div>
     <div class="team" style="justify-content: flex-end;">
      <span>
       Aston Villa
      </span>
      <img alt="Aston Villa logo" height="24" src="Aston Villa.png" width="24"/>
     </div>
    </div>
    <div class="match">
     <div class="team">
      <img alt="Real Madrid logo" height="24" src="Real Madrid.png" width="24"/>
      <span>
       Real Madrid
      </span>
     </div>
     <div class="score">
      3
     </div>
     <div class="status">
      FT
      <br/>
      Sep 18
     </div>
     <div class="score">
      1
     </div>
     <div class="team" style="justify-content: flex-end;">
      <span>
       VfB Stuttgart
      </span>
      <img alt="VfB Stuttgart logo" height="24" src="VfB Stuttgard.png" width="24"/>
     </div>
    </div>
    <div class="match">
     <div class="team">
      <img alt="Bayern logo" height="24" src="Bayren.png" width="24"/>
      <span>
       Bayern
      </span>
     </div>
     <div class="score">
      9
     </div>
     <div class="status">
      FT
      <br/>
      Sep 18
     </div>
     <div class="score">
      2
     </div>
     <div class="team" style="justify-content: flex-end;">
      <span>
       Dinamo Zagreb
      </span>
      <img alt="Dinamo Zagreb logo" height="24" src="Dinamo Zagreb.png" width="24"/>
     </div>
    </div>
    <div class="match">
     <div class="team">
      <img alt="Sporting logo" height="24" src="Sporting.png" width="24"/>
      <span>
       Sporting
      </span>
     </div>
     <div class="score">
      2
     </div>
     <div class="status">
      FT
      <br/>
      Sep 18
     </div>
     <div class="score">
      0
     </div>
     <div class="team" style="justify-content: flex-end;">
      <span>
       LOSC
      </span>
      <img alt="LOSC logo" height="24" src="LOSC.png" width="24"/>
     </div>
    </div>
    <div class="match">
     <div class="team">
      <img alt="Milan logo" height="24" src="Milan.png" width="24"/>
      <span>
       Milan
      </span>
     </div>
     <div class="score">
      1
     </div>
     <div class="status">
      FT
      <br/>
      Sep 18
     </div>
     <div class="score">
      3
     </div>
     <div class="team" style="justify-content: flex-end;">
      <span>
       Liverpool
      </span>
      <img alt="Liverpool logo" height="24" src="Liverpool.png" width="24"/>
     </div>
    </div>
    <div class="match">
     <div class="team">
      <img alt="Bologna logo" height="24" src="Bologna.png" width="24"/>
      <span>
       Bologna
      </span>
     </div>
     <div class="score">
      0
     </div>
     <div class="status">
      FT
      <br/>
      Sep 18
     </div>
     <div class="score">
      0
     </div>
     <div class="team" style="justify-content: flex-end;">
      <span>
       Shakhtar Donetsk
      </span>
      <img alt="Shakhtar Donetsk logo" height="24" src="Shaktar Donetsk.png" width="24"/>
     </div>
    </div>
    <div class="match">
     <div class="team">
      <img alt="Sparta Praha logo" height="24" src="Sparta Praha.png" width="24"/>
      <span>
       Sparta Praha
      </span>
     </div>
     <div class="score">
      3
     </div>
     <div class="status">
      FT
      <br>
      Sep 18
     </div>
     <div class="score">
      0
     </div>
     <div class="team" style="justify-content: flex-end;">
      <span>
       RB Salzburg
      </span>
      <img alt="RB Salzburg logo" height="24" src="RB Salzburg.png" width="24"/>
     </div>
    </div>
    <div class="match">
        <div class="team">
         <img alt="PSG logo" height="24" src="PSG.png" width="24"/>
         <span>
          PSG
         </span>
        </div>
        <div class="score">
         1
        </div>
        <div class="status">
         FT
         <br>
         Sep 19
        </div>
        <div class="score">
         0
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Girona
         </span>
         <img alt="Girona" height="24" src="Girona.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Club Brugge logo" height="24" src="Club Brugge.png" width="24"/>
         <span>
          Club Brugge
         </span>
        </div>
        <div class="score">
         0
        </div>
        <div class="status">
         FT
         <br/>
         Sep 19
        </div>
        <div class="score">
         3
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Dortmund
         </span>
         <img alt="Dortmund logo" height="24" src="Dortmund.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Celtic logo" height="24" src="Celtic.png" width="24"/>
         <span>
          Celtic
         </span>
        </div>
        <div class="score">
         5
        </div>
        <div class="status">
         FT
         <br/>
         Sep 19
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Slovan Bratislava
         </span>
         <img alt="Slovan Bratislava logo" height="24" src="Slovan Bratislava.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Man city logo" height="24" src="Man city.png" width="24"/>
         <span>
          Man city
         </span>
        </div>
        <div class="score">
         0
        </div>
        <div class="status">
         FT
         <br>
         Sep 19
        </div>
        <div class="score">
         0
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Inter
         </span>
         <img alt="Inter logo" height="24" src="Inter.png" width="24"/>
        </div>
    </div>
    <div class="match">
        <div class="team">
         <img alt="Crvena zvexda" height="24" src="Crvena zvezda.png" width="24"/>
         <span>
          Crvena zvexda
         </span>
        </div>
        <div class="score">
         1
        </div>
        <div class="status">
         FT
         <br>
         Sep 19
        </div>
        <div class="score">
         2
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Benfica
         </span>
         <img alt="Benfica logo" height="24" src="Benfica.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Feyenoord logo" height="24" src="Feyenoord.png" width="24"/>
         <span>
          Feyenoord
         </span>
        </div>
        <div class="score">
         0
        </div>
        <div class="status">
         FT
         <br>
         Sep 19
        </div>
        <div class="score">
         4
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Leverkusen
         </span>
         <img alt="Leverkusen logo" height="24" src="Leverkusen.png" width="24"/>
        </div>
    </div>
        <div class="match">
        <div class="team">
         <img alt="Brest logo" height="24" src="Brest.png" width="24"/>
         <span>
          Brest
         </span>
        </div>
        <div class="score">
         2
        </div>
        <div class="status">
         FT
         <br>
         Sep 20
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          SK Sturm Graz<img src="red card.svg">
         </span>
         <img alt="SK Sturm Graz logo" height="24" src="SK Sturm Graz.png" width="24"/>
        </div>
    </div>
    <div class="match">
        <div class="team">
         <img alt="Atalanta logo" height="24" src="Atalanta.png" width="24"/>
         <span>
          Atalanta
         </span>
        </div>
        <div class="score">
         0
        </div>
        <div class="status">
         FT
         <br>
         Sep 20
        </div>
        <div class="score">
         0
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Arsenal
         </span>
         <img alt="Arsenal logo" height="24" src="Arsenal.png" width="24"/>
        </div>
    </div>
    <div class="match">
        <div class="team">
         <img alt="Atletico Madrid logo" height="24" src="Atletico Madrid.png" width="24"/>
         <span>
          Atletico Madrid
         </span>
        </div>
        <div class="score">
         2
        </div>
        <div class="status">
         FT
         <br>
         Sep 20
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          RB Leipzig
         </span>
         <img alt="RB Leipzig logo" height="24" src="RB Leipzig.png" width="24"/>
        </div>
    </div>
    <div class="match">
        <div class="team">
         <img alt="Monaco logo" height="24" src="Monaco.png" width="24"/>
         <span>
          Monaco
         </span>
        </div>
        <div class="score">
         2
        </div>
        <div class="status">
         FT
         <br>
         Sep 20
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Barcelona<img src="red card.svg">
         </span>
         <img alt="Barcelona logo" height="24" src="Barcelona.png" width="24"/>
        </div>
    </div>
    <br> <br> <br>
    <div class="matchday">
        Matchday 2 of 8
       <div class="match">
        <div class="team">
         <img alt="RB Salzburg logo" height="24" src="RB Salzburg.png" width="24"/>
         <span>
          RB Salzburg
         </span>
        </div>
        <div class="score">
         0
        </div>
        <div class="status">
         FT
         <br/>
         Oct 1
        </div>
        <div class="score">
         4
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Brest
         </span>
         <img alt="Brest logo" height="24" src="Brest.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="VfB Stuttgart logo" height="24" src="VfB Stuttgard.png" width="24"/>
         <span>
          Vfb Stuttgart
         </span>
        </div>
        <div class="score">
         1
        </div>
        <div class="status">
         FT
         <br/>
         Oct 1
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Sparta Praha
         </span>
         <img alt="Sparta Praha logo" height="24" src="Sparta Praha.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Dortmund logo" height="24" src="Dortmund.png" width="24"/>
         <span>
          Dortmund
         </span>
        </div>
        <div class="score">
         7
        </div>
        <div class="status">
         FT
         <br/>
         Oct 2
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Celtic
         </span>
         <img alt="Celtic logo" height="24" src="Celtic.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="PSV logo" height="24" src="PSV.png" width="24"/>
         <span>
          PSV
         </span>
        </div>
        <div class="score">
         1
        </div>
        <div class="status">
         FT
         <br/>
         Oct 2
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Sporting
         </span>
         <img alt="Sporting logo" height="24" src="Sporting.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Slovan Bratislava logo" height="24" src="Slovan Bratislava.png" width="24"/>
         <span>
          Slovan Bratislava
         </span>
        </div>
        <div class="score">
         0
        </div>
        <div class="status">
         FT
         <br/>
         Oct 2
        </div>
        <div class="score">
         4
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Man City
         </span>
         <img alt="Man City logo" height="24" src="Man city.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Barcelona logo" height="24" src="Barcelona.png" width="24"/>
         <span>
          Barcelona
         </span>
        </div>
        <div class="score">
         5
        </div>
        <div class="status">
         FT
         <br/>
         Oct 2
        </div>
        <div class="score">
         0
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Young Boys
         </span>
         <img alt="Young Boys logo" height="24" src="Young Boys.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Leverkusen logo" height="24" src="Leverkusen.png" width="24"/>
         <span>
          Leverkusen
         </span>
        </div>
        <div class="score">
         1
        </div>
        <div class="status">
         FT
         <br/>
         Oct 2
        </div>
        <div class="score">
         0
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Milan
         </span>
         <img alt="Milan logo" height="24" src="Milan.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Inter logo" height="24" src="Inter.png" width="24"/>
         <span>
          Inter
         </span>
        </div>
        <div class="score">
         4
        </div>
        <div class="status">
         FT
         <br>
         Oct 2
        </div>
        <div class="score">
         0
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Crvena zvexda
         </span>
         <img alt="Crvena logo" height="24" src="Crvena zvezda.png" width="24"/>
        </div>
       </div>
       <div class="match">
           <div class="team">
            <img alt="Arsenal logo" height="24" src="Arsenal.png" width="24"/>
            <span>
             Arsenal
            </span>
           </div>
           <div class="score">
            2
           </div>
           <div class="status">
            FT
            <br>
            Oct 2
           </div>
           <div class="score">
            0
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             PSG
            </span>
            <img alt="PSG" height="24" src="PSG.png" width="24"/>
           </div>
          </div>
          <div class="match">
            <div class="team">
             <img alt="Shakhtar Donetsk logo" height="24" src="Shaktar Donetsk.png" width="24"/>
             <span>
              Shakhtar Donetsk
             </span>
            </div>
            <div class="score">
             0
            </div>
            <div class="status">
             FT
             <br/>
             Oct 2
            </div>
            <div class="score">
             3
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Atalanta
             </span>
             <img alt="Atalanta logo" height="24" src="Atalanta.png" width="24"/>
            </div>
           </div>
          <div class="match">
           <div class="team">
            <img alt="Girona logo" height="24" src="Girona.png" width="24"/>
            <span>
             Girona
            </span>
           </div>
           <div class="score">
            2
           </div>
           <div class="status">
            FT
            <br>
            Oct 2
           </div>
           <div class="score">
            3
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Feyenoord
            </span>
            <img alt="Feyenoord logo" height="24" src="Feyenoord.png" width="24"/>
           </div>
       </div>
       <div class="match">
           <div class="team">
            <img alt="SK Sturm Graz" height="24" src="SK Sturm Graz.png" width="24"/>
            <span>
             SK Strum Graz
            </span>
           </div>
           <div class="score">
            0
           </div>
           <div class="status">
            FT
            <br>
            Oct 3
           </div>
           <div class="score">
            1
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Club Brugge
            </span>
            <img alt="Club Brugge logo" height="24" src="Club Brugge.png" width="24"/>
           </div>
          </div>
          <div class="match">
           <div class="team">
            <img alt="Aston Villa logo" height="24" src="Aston Villa.png" width="24"/>
            <span>
              Aston Villa
            </span>
           </div>
           <div class="score">
            1
           </div>
           <div class="status">
            FT
            <br>
            Oct 3
           </div>
           <div class="score">
            0
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Bayren
            </span>
            <img alt="Bayren logo" height="24" src="Bayren.png" width="24"/>
           </div>
       </div>
           <div class="match">
           <div class="team">
            <img alt="Dinamo Zagreb logo" height="24" src="Dinamo Zagreb.png" width="24"/>
            <span>
             Dinamo Zagreb
            </span>
           </div>
           <div class="score">
            2
           </div>
           <div class="status">
            FT
            <br>
            Oct 3
           </div>
           <div class="score">
            2
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Monaco
            </span>
            <img alt="Monaco logo" height="24" src="Monaco.png" width="24"/>
           </div>
       </div>
       <div class="match">
           <div class="team">
            <img alt="Benfica logo" height="24" src="Benfica.png" width="24"/>
            <span>
             Benfica
            </span>
           </div>
           <div class="score">
            4
           </div>
           <div class="status">
            FT
            <br>
            Oct 3
           </div>
           <div class="score">
            0
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Atletico Madrid
            </span>
            <img alt="Atletico Madrid logo" height="24" src="Atletico Madrid.png" width="24"/>
           </div>
       </div>
       <div class="match">
           <div class="team">
            <img alt="Liverpool logo" height="24" src="Liverpool.png" width="24"/>
            <span>
             Liverpool
            </span>
           </div>
           <div class="score">
            2
           </div>
           <div class="status">
            FT
            <br>
            Oct 3
           </div>
           <div class="score">
            0
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Bologna
            </span>
            <img alt="Bologna logo" height="24" src="Bologna.png" width="24"/>
           </div>
       </div>
       <div class="match">
           <div class="team">
            <img alt="RB Leipzig logo" height="24" src="RB Leipzig.png" width="24"/>
            <span>
             RB Leipzig
            </span>
           </div>
           <div class="score">
            2
           </div>
           <div class="status">
            FT
            <br>
            Oct 3
           </div>
           <div class="score">
            3
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Juventus<img src="red card.svg">
            </span>
            <img alt="Juventus logo" height="24" src="Juventus.png" width="24"/>
           </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="LOSC logo" height="24" src="LOSC.png" width="24"/>
         <span>
          LOSC
         </span>
        </div>
        <div class="score">
         1
        </div>
        <div class="status">
         FT
         <br/>
         Oct 3
        </div>
        <div class="score">
         0
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Real Madrid
         </span>
         <img alt="Real Madrid logo" height="24" src="Real Madrid.png" width="24"/>
        </div>
       </div>
       <br> <br> <br>
    <div class="matchday">
        Matchday 3 of 8
       <div class="match">
        <div class="team">
         <img alt="Monaco logo" height="24" src="Monaco.png" width="24"/>
         <span>
          Monaco
         </span>
        </div>
        <div class="score">
         5
        </div>
        <div class="status">
         FT
         <br/>
         Oct 22
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Crvena zvezda
         </span>
         <img alt="Crvena zvezda logo" height="24" src="Crvena zvezda.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Milan logo" height="24" src="Milan.png" width="24"/>
         <span>
          Milan
         </span>
        </div>
        <div class="score">
         3
        </div>
        <div class="status">
         FT
         <br/>
         Oct 22
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Club Brugge<img src="red card.svg">
         </span>
         <img alt="Club Brugge logo" height="24" src="Club Brugge.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Arsenal logo" height="24" src="Arsenal.png" width="24"/>
         <span>
          Arsenal
         </span>
        </div>
        <div class="score">
         1
        </div>
        <div class="status">
         FT
         <br/>
         Oct 22
        </div>
        <div class="score">
         0
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Shakhtar Donetsk
         </span>
         <img alt="Shakthar Dobetsk logo" height="24" src="Shaktar Donetsk.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Juventus logo" height="24" src="Juventus.png" width="24"/>
         <span>
          Juventus<img src="red card.svg">
         </span>
        </div>
        <div class="score">
         0
        </div>
        <div class="status">
         FT
         <br/>
         Oct 23
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          VfB Stuttgart
         </span>
         <img alt="VfB Stuttgart logo" height="24" src="VfB Stuttgard.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="SK Sturm Graz logo" height="24" src="SK Sturm Graz.png" width="24"/>
         <span>
          SK Sturm Graz
         </span>
        </div>
        <div class="score">
         0
        </div>
        <div class="status">
         FT
         <br/>
         Oct 23
        </div>
        <div class="score">
         2
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Sporting
         </span>
         <img alt="Sporting logo" height="24" src="Sporting.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Real Madrid logo" height="24" src="Real Madrid.png" width="24"/>
         <span>
          Real Madrid
         </span>
        </div>
        <div class="score">
         5
        </div>
        <div class="status">
         FT
         <br/>
         Oct 23
        </div>
        <div class="score">
         2
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Dortmund
         </span>
         <img alt="Dortmund logo" height="24" src="Dortmund.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="PSG logo" height="24" src="PSG.png" width="24"/>
         <span>
          PSG
         </span>
        </div>
        <div class="score">
         1
        </div>
        <div class="status">
         FT
         <br/>
         Oct 23
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          PSV
         </span>
         <img alt="PSV logo" height="24" src="PSV.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Girona logo" height="24" src="Girona.png" width="24"/>
         <span>
          Girona
         </span>
        </div>
        <div class="score">
         2
        </div>
        <div class="status">
         FT
         <br>
         Oct 23
        </div>
        <div class="score">
         0
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Slovan Bratislava
         </span>
         <img alt="Slovan Bratislava logo" height="24" src="Slovan Bratislava.png" width="24"/>
        </div>
       </div>
       <div class="match">
           <div class="team">
            <img alt="Aston Villa logo" height="24" src="Aston Villa.png" width="24"/>
            <span>
             Aston Villa
            </span>
           </div>
           <div class="score">
            2
           </div>
           <div class="status">
            FT
            <br>
            Oct 23
           </div>
           <div class="score">
            0
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Bologna
            </span>
            <img alt="Bologna" height="24" src="Bologna.png" width="24"/>
           </div>
          </div>
          <div class="match">
            <div class="team">
             <img alt="Atalanta logo" height="24" src="Atalanta.png" width="24"/>
             <span>
              Atalanta
             </span>
            </div>
            <div class="score">
             0
            </div>
            <div class="status">
             FT
             <br/>
             Oct 23
            </div>
            <div class="score">
             0
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Celtic
             </span>
             <img alt="Celtic logo" height="24" src="Celtic.png" width="24"/>
            </div>
           </div>
          <div class="match">
           <div class="team">
            <img alt="Brest logo" height="24" src="Brest.png" width="24"/>
            <span>
             Brest
            </span>
           </div>
           <div class="score">
            1
           </div>
           <div class="status">
            FT
            <br>
            Oct 23
           </div>
           <div class="score">
            1
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Leverkusen
            </span>
            <img alt="Leverkusen logo" height="24" src="Leverkusen.png" width="24"/>
           </div>
       </div>
       <div class="match">
           <div class="team">
            <img alt="RB Leipzig" height="24" src="RB Leipzig.png" width="24"/>
            <span>
             RB Leipzig
            </span>
           </div>
           <div class="score">
            0
           </div>
           <div class="status">
            FT
            <br>
            Oct 24
           </div>
           <div class="score">
            1
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Liverpool
            </span>
            <img alt="Liverpool logo" height="24" src="Liverpool.png" width="24"/>
           </div>
          </div>
          <div class="match">
           <div class="team">
            <img alt="Man City logo" height="24" src="Man city.png" width="24"/>
            <span>
              Man City
            </span>
           </div>
           <div class="score">
            5
           </div>
           <div class="status">
            FT
            <br>
            Oct 24
           </div>
           <div class="score">
            0
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Sparta Praha
            </span>
            <img alt="Sparta Praha logo" height="24" src="Sparta Praha.png" width="24"/>
           </div>
       </div>
       <a href="Barcelona vs Bayren.html">
           <div class="match">
           <div class="team">
            <img alt="Barcelona logo" height="24" src="Barcelona.png" width="24"/>
            <span>
             Barcelona
            </span>
           </div>
           <div class="score">
            4
           </div>
           <div class="status">
            FT
            <br>
            Oct 24
           </div>
           <div class="score">
            1
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Bayren
            </span>
            <img alt="Bayren logo" height="24" src="Bayren.png" width="24"/>
           </div>
       </div>
       </a>
       <a href="Athletico vs LOSC.html">
       <div class="match">
           <div class="team">
            <img alt="Atletico Madrid logo" height="24" src="Atletico Madrid.png" width="24"/>
            <span>
             Atletico Madrid
            </span>
           </div>
           <div class="score">
            1
           </div>
           <div class="status">
            FT
            <br>
            Oct 24
           </div>
           <div class="score">
            3
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             LOSC
            </span>
            <img alt="LOSC logo" height="24" src="LOSC.png" width="24"/>
           </div>
       </div>
       </a>
       <a href="RB Salzburg vs Dinamo Zagreb.html">
       <div class="match">
           <div class="team">
            <img alt="RB Salzburg logo" height="24" src="RB Salzburg.png" width="24"/>
            <span>
             RB Salzburg<img src="red card.svg">
            </span>
           </div>
           <div class="score">
            0
           </div>
           <div class="status">
            FT
            <br>
            Oct 24
           </div>
           <div class="score">
            2
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Dinamo Zagreb
            </span>
            <img alt="Dinamo Zagreb logo" height="24" src="Dinamo Zagreb.png" width="24"/>
           </div>
       </div>
       </a>
       <a href="Benfica vs Feyrnoord.html">
       <div class="match">
           <div class="team">
            <img alt="Benfica logo" height="24" src="Benfica.png" width="24"/>
            <span>
             Benfica
            </span>
           </div>
           <div class="score">
            1
           </div>
           <div class="status">
            FT
            <br>
            Oct 24
           </div>
           <div class="score">
            3
           </div>
           <div class="team" style="justify-content: flex-end;">
            <span>
             Feyenoord
            </span>
            <img alt="Feyenoord logo" height="24" src="Feyenoord.png" width="24"/>
           </div>
       </div>
       </a>
       <a href="Young Boys vs Inter.html">
       <div class="match">
        <div class="team">
         <img alt="Young Boys logo" height="24" src="Young Boys.png" width="24"/>
         <span>
          Young Boys
         </span>
        </div>
        <div class="score">
         0
        </div>
        <div class="status">
         FT
         <br/>
         Oct 24
        </div>
        <div class="score">
         1
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Inter
         </span>
         <img alt="Inter logo" height="24" src="Inter.png" width="24"/>
        </div>
       </div>
       </a>
       <br> <br> <br>
       <div class="matchday">
        Matchday 4 of 8
       <div class="match">
        <div class="team">
         <img alt="Slovan Bratislava logo" height="24" src="Slovan Bratislava.png" width="24"/>
         <span>
          Slovan Bratislava
         </span>
        </div>
        <div class="status">
         Nov 5
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Dinamo Zagreb
         </span>
         <img alt="Dinamo Zagreb logo" height="24" src="Dinamo Zagreb.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="PSV logo" height="24" src="PSV.png" width="24"/>
         <span>
          PSV
         </span>
        </div>
        <div class="status">
         Nov 5
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Girona
         </span>
         <img alt="Girona logo" height="24" src="Girona.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Dortmund logo" height="24" src="Dortmund.png" width="24"/>
         <span>
          Dortmund
         </span>
        </div>
        <div class="status">
         Nov 6
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          SK Sturm Graz
         </span>
         <img alt="SK Strum Graz logo" height="24" src="SK Sturm Graz.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Celtic logo" height="24" src="Celtic.png" width="24"/>
         <span>
          Celtic
         </span>
        </div>
        <div class="status">
         Nov 6
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          RB Leipzig
         </span>
         <img alt="RB Leipzig logo" height="24" src="RB Leipzig.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Real Madrid logo" height="24" src="Real Madrid.png" width="24"/>
         <span>
          Real Madrid
         </span>
        </div>
        <div class="status">
         Nov 6
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Milan
         </span>
         <img alt="Milan logo" height="24" src="Milan.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="LOSC logo" height="24" src="LOSC.png" width="24"/>
         <span>
          LOSC
         </span>
        </div>
        <div class="status">
         Nov 6
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Juventus
         </span>
         <img alt="Juventus logo" height="24" src="Juventus.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Liverpool logo" height="24" src="Liverpool.png" width="24"/>
         <span>
          Liverpool
         </span>
        </div>
        <div class="status">
         Nov 6
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Leverkusen
         </span>
         <img alt="Leverkusen logo" height="24" src="Liverpool.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Sporting logo" height="24" src="Sporting.png" width="24"/>
         <span>
          Sporting
         </span>
        </div>
        <div class="status">
         Nov 6
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Man City
         </span>
         <img alt="Man City logo" height="24" src="Man city.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Bologna logo" height="24" src="Bologna.png" width="24"/>
         <span>
          Monaco
         </span>
        </div>
        <div class="status">
         Nov 6
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Monaco
         </span>
         <img alt="Monaco logo" height="24" src="Monaco.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Shaktar Donetsk logo" height="24" src="Shaktar Donetsk.png" width="24"/>
         <span>
          Shakhtar Donetsk
         </span>
        </div>
        <div class="status">
         Nov 6
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Young Boys
         </span>
         <img alt="Young Boys logo" height="24" src="Young Boys.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Club Brugge logo" height="24" src="Club Brugge.png" width="24"/>
         <span>
          Club Brugge
         </span>
        </div>
        <div class="status">
         Nov 6
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Aston Villa
         </span>
         <img alt="Aston Villa logo" height="24" src="Aston Villa.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Feyenoord logo" height="24" src="Feyenoord.png" width="24"/>
         <span>
          Feyenoord
         </span>
        </div>
        <div class="status">
         Nov 7
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Rb Salzburg
         </span>
         <img alt="RB Salzburg logo" height="24" src="RB Salzburg.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="PSG logo" height="24" src="PSG.png" width="24"/>
         <span>
          PSG
         </span>
        </div>
        <div class="status">
         Nov 7
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Atletico Madrid
         </span>
         <img alt="Atletico Madrid logo" height="24" src="Atletico Madrid.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Bayern logo" height="24" src="Bayren.png" width="24"/>
         <span>
          Bayren
         </span>
        </div>
        <div class="status">
         Nov 7
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Benfica
         </span>
         <img alt="Benfica logo" height="24" src="Benfica.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Sparta Praha logo" height="24" src="Sparta Praha.png" width="24"/>
         <span>
          Sparta Praha
         </span>
        </div>
        <div class="status">
         Nov 7
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Brest
         </span>
         <img alt="Brest logo" height="24" src="Brest.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Crvena zvezda logo" height="24" src="Crvena zvezda.png" width="24"/>
         <span>
          Crvena zvezda
         </span>
        </div>
        <div class="status">
         Nov 7
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Barcelona
         </span>
         <img alt="Barcelona logo" height="24" src="Barcelona.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="Inter logo" height="24" src="Inter.png" width="24"/>
         <span>
          Inter
         </span>
        </div>
        <div class="status">
         Nov 7
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Arsenal
         </span>
         <img alt="Arsenal logo" height="24" src="Arsenal.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img alt="VfB Stuttgard logo" height="24" src="VfB Stuttgard.png" width="24"/>
         <span>
          VfB Stuttgard
         </span>
        </div>
        <div class="status">
         Nov 7
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Atalanta
         </span>
         <img alt="Atalanta logo" height="24" src="Atalanta.png" width="24"/>
        </div>
       </div>
       <br> <br> <br>
       <div class="matchday">
        Matchday 5 of 8
       <div class="match">
        <div class="team">
         <img height="24" src="Slovan Bratislava.png" width="24"/>
         <span>
          Slovan Bratislava
         </span>
        </div>
        <div class="status">
         Nov 26
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Milan
         </span>
         <img height="24" src="Milan.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Sparta Praha.png" width="24"/>
         <span>
          Sparta Praha
         </span>
        </div>
        <div class="status">
         Nov 26
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Atletico Madrid
         </span>
         <img height="24" src="Atletico Madrid.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Man city.png" width="24"/>
         <span>
          Man City
         </span>
        </div>
        <div class="status">
         Nov 27
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Feyenoord
         </span>
         <img height="24" src="Feyenoord.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Barcelona.png" width="24"/>
         <span>
          Barcelona
         </span>
        </div>
        <div class="status">
         Nov 27
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Brest
         </span>
         <img height="24" src="Brest.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Bayren.png" width="24"/>
         <span>
          Bayren
         </span>
        </div>
        <div class="status">
         Nov 27
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          PSG
         </span>
         <img height="24" src="PSG.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Inter.png" width="24"/>
         <span>
          Inter
         </span>
        </div>
        <div class="status">
         Nov 27
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          RB Leipzig
         </span>
         <img height="24" src="RB Leipzig.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Young Boys.png" width="24"/>
         <span>
          Young Boys
         </span>
        </div>
        <div class="status">
         Nov 27
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Atalanta
         </span>
         <img height="24" src="Atalanta.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Leverkusen.png" width="24"/>
         <span>
          Leverkusen
         </span>
        </div>
        <div class="status">
         Nov 27
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          RB Salzburg
         </span>
         <img height="24" src="RB Salzburg.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Sporting.png" width="24"/>
         <span>
          Sporting
         </span>
        </div>
        <div class="status">
         Nov 27
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Arsenal
         </span>
         <img height="24" src="Arsenal.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Crvena zvezda.png" width="24"/>
         <span>
          Crvena zvezda
         </span>
        </div>
        <div class="status">
         Nov 27
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          VfB Stuttgard
         </span>
         <img height="24" src="VfB Stuttgard.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="SK Sturm Graz.png" width="24"/>
         <span>
          SK Sturm Graz
         </span>
        </div>
        <div class="status">
         Nov 27
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Girona
         </span>
         <img height="24" src="Girona.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Aston Villa.png" width="24"/>
         <span>
          Aston Villa
         </span>
        </div>
        <div class="status">
         Nov 28
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Juventus
         </span>
         <img height="24" src="Juventus.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Monaco.png" width="24"/>
         <span>
          Monaco
         </span>
        </div>
        <div class="status">
         Nov 28
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Benfica
         </span>
         <img height="24" src="Benfica.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="PSV.png" width="24"/>
         <span>
          PSV
         </span>
        </div>
        <div class="status">
         Nov 28
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Shakhtar Donetsk
         </span>
         <img height="24" src="Shaktar Donetsk.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Liverpool.png" width="24"/>
         <span>
          Liverpool
         </span>
        </div>
        <div class="status">
         Nov 28
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Real Madrid
         </span>
         <img height="24" src="Real Madrid.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Celtic.png" width="24"/>
         <span>
          Celtic
         </span>
        </div>
        <div class="status">
         Nov 28
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Club Brugge
         </span>
         <img height="24" src="Club Brugge.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Bologna.png" width="24"/>
         <span>
          Bologna
         </span>
        </div>
        <div class="status">
         Nov 28
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          LOSC
         </span>
         <img height="24" src="LOSC.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Dinamo Zagreb.png" width="24"/>
         <span>
          Dinamo Zagreb
         </span>
        </div>
        <div class="status">
         Nov 28
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Dortmund
         </span>
         <img height="24" src="Dortmund.png" width="24"/>
        </div>
       </div>
       <br> <br> <br>
       <div class="matchday">
        Matchday 6 of 8
       <div class="match">
        <div class="team">
         <img height="24" src="Dinamo Zagreb.png" width="24"/>
         <span>
          Dinamo Zagreb
         </span>
        </div>
        <div class="status">
         Dec 10
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Celtic
         </span>
         <img height="24" src="Celtic.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Girona.png" width="24"/>
         <span>
          Girona
         </span>
        </div>
        <div class="status">
         Dec 10
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Liverpool
         </span>
         <img height="24" src="Liverpool.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Brest.png" width="24"/>
         <span>
          Brest
         </span>
        </div>
        <div class="status">
         Dec 11
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          PSV
         </span>
         <img height="24" src="PSV.png" width="24"/>
        </div>
       </div>
       <div class="match">
       <div class="team">
        <img height="24" src="Shaktar Donetsk.png" width="24"/>
        <span>
         Shakhtar Donetsk
        </span>
       </div>
       <div class="status">
        Dec 11
        <br/>
        01:45
       </div>
       <div class="team" style="justify-content: flex-end;">
        <span>
         Bayren
        </span>
        <img height="24" src="Bayren.png" width="24"/>
       </div>
      </div>
      <div class="match">
        <div class="team">
         <img height="24" src="Club Brugge.png" width="24"/>
         <span>
          Club Brugge
         </span>
        </div>
        <div class="status">
         Dec 11
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Sporting
         </span>
         <img height="24" src="Sporting.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="RB Salzburg.png" width="24"/>
         <span>
          RB Salzburg
         </span>
        </div>
        <div class="status">
         Dec 11
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          PSG
         </span>
         <img height="24" src="PSG.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="RB Leipzig.png" width="24"/>
         <span>
          RB Leipzig
         </span>
        </div>
        <div class="status">
         Dec 11
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Aston Villa
         </span>
         <img height="24" src="Aston Villa.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Leverkusen.png" width="24"/>
         <span>
          Leverkusen
         </span>
        </div>
        <div class="status">
         Dec 11
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Inter
         </span>
         <img height="24" src="Inter.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Atalanta.png" width="24"/>
         <span>
          Atalanta
         </span>
        </div>
        <div class="status">
         Dec 11
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          REal Madrid
         </span>
         <img height="24" src="Real Madrid.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Atletico Madrid.png" width="24"/>
         <span>
          Atletico Madrid
         </span>
        </div>
        <div class="status">
         Dec 11
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Slovan Bratislava
         </span>
         <img height="24" src="Slovan Bratislava.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="LOSC.png" width="24"/>
         <span>
          LOSC
         </span>
        </div>
        <div class="status">
         Dec 11
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          SK Sturm Graz
         </span>
         <img height="24" src="SK Sturm Graz.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Benfica.png" width="24"/>
         <span>
          Benfica
         </span>
        </div>
        <div class="status">
         Dec 12
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Bologna
         </span>
         <img height="24" src="Bologna.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Milan.png" width="24"/>
         <span>
          Milan
         </span>
        </div>
        <div class="status">
         Dec 12
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Crvena zvezda
         </span>
         <img height="24" src="Crvena zvezda.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Dortmund.png" width="24"/>
         <span>
          Dortmund
         </span>
        </div>
        <div class="status">
         Dec 12
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Barcelona
         </span>
         <img height="24" src="Barcelona.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Feyenoord.png" width="24"/>
         <span>
          Feyenoord
         </span>
        </div>
        <div class="status">
         Dec 12
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Sparta Praha
         </span>
         <img height="24" src="Sparta Praha.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Juventus.png" width="24"/>
         <span>
          Juventus
         </span>
        </div>
        <div class="status">
         Dec 12
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Man City
         </span>
         <img height="24" src="Man city.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="VfB Stuttgard.png" width="24"/>
         <span>
          VfB Stuttgard
         </span>
        </div>
        <div class="status">
         Dec 12
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Young Boys
         </span>
         <img height="24" src="Young Boys.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Arsenal.png" width="24"/>
         <span>
          Arsenal
         </span>
        </div>
        <div class="status">
         Dec 12
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Monaco
         </span>
         <img height="24" src="Monaco.png" width="24"/>
        </div>
       </div>
    </div>
    <br> <br> <br>
    <div class="matchday">
        Matchday 7 of 8
       <div class="match">
        <div class="team">
         <img height="24" src="Monaco.png" width="24"/>
         <span>
          Monaco
         </span>
        </div>
        <div class="status">
         Jan 21
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Aston Villa
         </span>
         <img height="24" src="Aston Villa.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Atalanta.png" width="24"/>
         <span>
          Atalanta
         </span>
        </div>
        <div class="status">
         Jan 21
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          SK Strum Graz
         </span>
         <img height="24" src="SK Sturm Graz.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Atletico Madrid.png" width="24"/>
         <span>
          Atletico Madrid
         </span>
        </div>
        <div class="status">
         Jan 22
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Leverkusen
         </span>
         <img height="24" src="Leverkusen.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Benfica.png" width="24"/>
         <span>
          Benfica
         </span>
        </div>
        <div class="status">
         Jan 22
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Barcelona
         </span>
         <img height="24" src="Barcelona.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Crvena zvezda.png" width="24"/>
         <span>
          Crvena zvezda
         </span>
        </div>
        <div class="status">
         Jan 22
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          PSV
         </span>
         <img height="24" src="PSV.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Liverpool.png" width="24"/>
         <span>
          Liverpool
         </span>
        </div>
        <div class="status">
         Jan 22
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          LOSC
         </span>
         <img height="24" src="LOSC.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Club Brugge.png" width="24"/>
         <span>
           Club Brugge
         </span>
        </div>
        <div class="status">
         Jan 22
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Juventus
         </span>
         <img height="24" src="Juventus.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Slovan Bratislava.png" width="24"/>
         <span>
          Slovan Bratislava
         </span>
        </div>
        <div class="status">
         Jan 22
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          VfB Stuttgard
         </span>
         <img height="24" src="VfB Stuttgard.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Bologna.png" width="24"/>
         <span>
          Bologna
         </span>
        </div>
        <div class="status">
         Jan 22
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Dortmund
         </span>
         <img height="24" src="Dortmund.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="RB Leipzig.png" width="24"/>
         <span>
          RB Leipzig
         </span>
        </div>
        <div class="status">
         Jan 22
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Sporting
         </span>
         <img height="24" src="Sporting.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Shaktar Donetsk.png" width="24"/>
         <span>
          Shakhtar Donetsk
         </span>
        </div>
        <div class="status">
         Jan 22
         <br/>
         23:30
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Brest
         </span>
         <img height="24" src="Brest.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Sparta Praha.png" width="24"/>
         <span>
          Sparta Praha
         </span>
        </div>
        <div class="status">
         Jan 23
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Inter
         </span>
         <img height="24" src="Inter.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Feyenoord.png" width="24"/>
         <span>
          Feyenoord
         </span>
        </div>
        <div class="status">
         Jan 23
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Bayren
         </span>
         <img height="24" src="Bayren.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Arsenal.png" width="24"/>
         <span>
          Arsenal
         </span>
        </div>
        <div class="status">
         Jan 23
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Dinamo Zagreb
         </span>
         <img height="24" src="Dinamo Zagreb.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Milan.png" width="24"/>
         <span>
          Milan
         </span>
        </div>
        <div class="status">
         Jan 23
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Girona
         </span>
         <img height="24" src="Girona.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="PSG.png" width="24"/>
         <span>
          PSG
         </span>
        </div>
        <div class="status">
         Jan 23
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Man City
         </span>
         <img height="24" src="Man city.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Real Madrid.png" width="24"/>
         <span>
          Real Madrid
         </span>
        </div>
        <div class="status">
         Jan 23
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          RB Salzburg
         </span>
         <img height="24" src="RB Salzburg.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Celtic.png" width="24"/>
         <span>
          Celtic
         </span>
        </div>
        <div class="status">
         Jan 23
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Young Boys
         </span>
         <img height="24" src="Young Boys.png" width="24"/>
        </div>
       </div>
       <br> <br> <br>
       <div class="matchday">
        Matchday 8 of 8
       <div class="match">
        <div class="team">
         <img height="24" src="PSV.png" width="24"/>
         <span>
          PSV
         </span>
        </div>
        <div class="status">
         Jan 30,25
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Liverpool
         </span>
         <img height="24" src="Liverpool.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Bayren.png" width="24"/>
         <span>
          Bayren
         </span>
        </div>
        <div class="status">
         Jan 30,25
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Slovan Bratislava
         </span>
         <img height="24" src="Slovan Bratislava.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Dortmund.png" width="24"/>
         <span>
          Dortmund
         </span>
        </div>
        <div class="status">
         Jan 30,25
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Shakhtar Donetsk
         </span>
         <img height="24" src="Shaktar Donetsk.png" width="24"/>
        </div>
       </div>
       <div class="match">
        <div class="team">
         <img height="24" src="Leverkusen.png" width="24"/>
         <span>
          Leverkusen
         </span>
        </div>
        <div class="status">
         Jan 30,25
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Sparta Praha
         </span>
         <img height="24" src="Sparta Praha.png" width="24"/>
        </div>
       </div>
        <div class="match">
        <div class="team">
         <img height="24" src="Girona.png" width="24"/>
         <span>
          Girona
         </span>
        </div>
        <div class="status">
         Jan 30,25
         <br/>
         01:45
        </div>
        <div class="team" style="justify-content: flex-end;">
         <span>
          Arsenal
         </span>
         <img height="24" src="Arsenal.png" width="24"/>
        </div>
        </div>
        <div class="match">
            <div class="team">
             <img height="24" src="Barcelona.png" width="24"/>
             <span>
              Barcelona
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Atalanta
             </span>
             <img height="24" src="Atalanta.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="Brest.png" width="24"/>
             <span>
              Brest
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Real Madrid
             </span>
             <img height="24" src="Real Madrid.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="Man city.png" width="24"/>
             <span>
              Man City
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Club Brugge
             </span>
             <img height="24" src="Club Brugge.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="Young Boys.png" width="24"/>
             <span>
              Young Boys
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Crvena zvezda
             </span>
             <img height="24" src="Crvena zvezda.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="LOSC.png" width="24"/>
             <span>
              LOSC
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Feyenoord
             </span>
             <img height="24" src="Feyenoord.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="Juventus.png" width="24"/>
             <span>
              Juventus
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Benfica
             </span>
             <img height="24" src="Benfica.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="Aston Villa.png" width="24"/>
             <span>
              Aston Villa
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Celtic
             </span>
             <img height="24" src="Celtic.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="Dinamo Zagreb.png" width="24"/>
             <span>
              Dinamo Zagreb
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Milan
             </span>
             <img height="24" src="Milan.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="Inter.png" width="24"/>
             <span>
              Inter
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Monaco
             </span>
             <img height="24" src="Monaco.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="RB Salzburg.png" width="24"/>
             <span>
              RB Salzburg
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Atletico Madrid
             </span>
             <img height="24" src="Atletico Madrid.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="SK Sturm Graz.png" width="24"/>
             <span>
              SK Sturm Graz
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              RB Leipzig
             </span>
             <img height="24" src="RB Leipzig.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="Sporting.png" width="24"/>
             <span>
              Sporting
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              Bologna
             </span>
             <img height="24" src="Bologna.png" width="24"/>
            </div>
           </div>
           <div class="match">
            <div class="team">
             <img height="24" src="VfB Stuttgard.png" width="24"/>
             <span>
              VfB Stuttgard
             </span>
            </div>
            <div class="status">
             Jan 30,25
             <br/>
             01:45
            </div>
            <div class="team" style="justify-content: flex-end;">
             <span>
              PSG
             </span>
             <img height="24" src="PSG.png" width="24"/>
            </div>
           </div>
       </div>"?>
  </body>
</html>